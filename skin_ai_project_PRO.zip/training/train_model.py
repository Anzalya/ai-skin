
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model

IMG = (224,224)
BATCH = 32

datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.2
)

train = datagen.flow_from_directory(
    "data/train",
    target_size=IMG,
    batch_size=BATCH,
    subset="training"
)

val = datagen.flow_from_directory(
    "data/train",
    target_size=IMG,
    batch_size=BATCH,
    subset="validation"
)

base = EfficientNetB0(weights="imagenet", include_top=False, input_shape=(224,224,3))

x = base.output
x = GlobalAveragePooling2D()(x)
x = Dense(256, activation="relu")(x)
out = Dense(train.num_classes, activation="softmax")(x)

model = Model(inputs=base.input, outputs=out)

model.compile(
    optimizer="adam",
    loss="categorical_crossentropy",
    metrics=["accuracy"]
)

model.fit(train, validation_data=val, epochs=15)

model.save("models/skin_model.h5")
