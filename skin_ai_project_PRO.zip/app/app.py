
import streamlit as st
import cv2
from app.predict import predict
from utils.disease_info import disease_info

st.title("AI Skin Disease Detector")

run = st.checkbox("Open Camera")

FRAME = st.image([])

cam = cv2.VideoCapture(0)

while run:
    ret, frame = cam.read()
    if not ret:
        st.write("Camera error")
        break

    img = cv2.resize(frame,(224,224))

    disease, conf = predict(img)
    info = disease_info.get(disease)

    cv2.putText(frame, disease,(20,40),
                cv2.FONT_HERSHEY_SIMPLEX,1,(0,255,0),2)

    FRAME.image(frame, channels="BGR")

    st.subheader("Prediction")
    st.write("Disease:", disease)
    st.write("Confidence:", round(conf*100,2), "%")
    st.write("Description:", info["description"])
    st.write("Recommendation:", info["recommendation"])
