
import cv2
from app.predict import predict
from utils.disease_info import disease_info

cap = cv2.VideoCapture(0)

rotation = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break

    if rotation != 0:
        frame = cv2.rotate(frame, rotation)

    img = cv2.resize(frame,(224,224))

    disease, conf = predict(img)

    text = f"{disease} {round(conf*100,2)}%"

    cv2.putText(frame,text,(20,40),
                cv2.FONT_HERSHEY_SIMPLEX,1,(0,255,0),2)

    cv2.imshow("AI Skin Detector",frame)

    key = cv2.waitKey(1)

    if key == ord('q'):
        break
    elif key == ord('r'):
        rotation = cv2.ROTATE_90_CLOCKWISE

cap.release()
cv2.destroyAllWindows()
