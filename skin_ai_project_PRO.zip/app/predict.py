
import numpy as np
import tensorflow as tf
from utils.disease_info import disease_info

classes = list(disease_info.keys())

try:
    model = tf.keras.models.load_model("models/skin_model.h5")
except:
    model = None

def predict(img):
    if model is None:
        return "Normal Skin", 0.0

    img = img/255.0
    img = np.expand_dims(img, axis=0)
    preds = model.predict(img)

    idx = np.argmax(preds)
    conf = float(preds[0][idx])

    return classes[idx], conf
