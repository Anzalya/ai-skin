disease_info = {
    "Acne": {
        "description": "Inflammatory skin condition causing pimples, blackheads, and whiteheads.",
        "recommendation": "Use non\u2011comedogenic skincare and consult a dermatologist if severe."
    },
    "Melanoma": {
        "description": "Serious type of skin cancer developing in pigment\u2011producing cells.",
        "recommendation": "URGENT: seek dermatologist consultation immediately."
    },
    "Psoriasis": {
        "description": "Autoimmune disease causing red, scaly skin patches.",
        "recommendation": "Dermatologist consultation recommended for proper therapy."
    },
    "Eczema": {
        "description": "Chronic inflammatory skin disease causing itching and redness.",
        "recommendation": "Use moisturizers and consult a dermatologist if persistent."
    },
    "Rosacea": {
        "description": "Chronic condition causing redness and visible blood vessels on the face.",
        "recommendation": "Consult dermatologist for treatment options."
    },
    "Vitiligo": {
        "description": "Condition where skin loses pigment creating white patches.",
        "recommendation": "Medical consultation recommended."
    },
    "Fungal Infection": {
        "description": "Skin infection caused by fungi, often itchy or scaly.",
        "recommendation": "Antifungal treatment and medical advice recommended."
    },
    "Normal Skin": {
        "description": "No visible disease detected.",
        "recommendation": "Maintain a healthy skincare routine."
    }
}