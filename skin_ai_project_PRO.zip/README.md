
# AI Skin Disease Detection (Pro Version)

Features:
- Deep learning classification (EfficientNet)
- Webcam real‑time detection
- Camera rotation
- Web interface (Streamlit)
- Medical description + recommendation
- Explainable AI (GradCAM heatmap)

Run training:
python training/train_model.py

Run camera detection:
python app/camera.py

Run web app:
streamlit run app/app.py
